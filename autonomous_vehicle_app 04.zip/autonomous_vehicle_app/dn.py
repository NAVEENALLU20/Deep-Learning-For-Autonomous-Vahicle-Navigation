import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
import joblib

# Load dataset
df = pd.read_csv("autonomous_vehicle_dataset.csv")

# Define features and target
features = [
    'Distance to Obstacles (m)', 'Speed (m/s)', 'Heading Angle (degrees)',
    'Lane Position (m)', 'Acceleration (m/s^2)', 'Turn Rate (degrees/s)',
    'Sensor Data 1', 'Sensor Data 2', 'Sensor Data 3', 'Sensor Data 4'
]
target = 'Action'

X = df[features]
y = df[target]

# Encode labels
label_encoder = LabelEncoder()
y_encoded = label_encoder.fit_transform(y)

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(X, y_encoded, test_size=0.2, random_state=42)

# Train RandomForest
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Save compatible model
joblib.dump(model, "autonomous_vehicle_model_compatible.joblib")
joblib.dump(label_encoder, "label_encoder_compatible.joblib")
