
from flask import Flask, render_template, request
import numpy as np
import joblib

app = Flask(__name__)

# Load the trained Scikit-learn model
model = joblib.load('autonomous_vehicle_model_compatible.joblib')
label_encoder = joblib.load('label_encoder_compatible.joblib')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        user_input = [
            float(request.form['distance']),
            float(request.form['speed']),
            float(request.form['heading']),
            float(request.form['lane_position']),
            float(request.form['acceleration']),
            float(request.form['turn_rate']),
            float(request.form['sensor1']),
            float(request.form['sensor2']),
            float(request.form['sensor3']),
            float(request.form['sensor4'])
        ]
        user_input_np = np.array([user_input])
        prediction = model.predict(user_input_np)
        predicted_action = label_encoder.inverse_transform(prediction)[0]
        return render_template('index.html', predicted_action=predicted_action)
    except Exception as e:
        return render_template('index.html', predicted_action=f"Error: {str(e)}")

if __name__ == '__main__':
    app.run(debug=True)
