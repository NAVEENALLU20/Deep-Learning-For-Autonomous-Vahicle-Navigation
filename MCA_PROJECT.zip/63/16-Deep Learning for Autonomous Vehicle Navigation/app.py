from flask import Flask, render_template, request
import numpy as np
from tensorflow.keras.models import load_model
import joblib

app = Flask(__name__)

# Load the trained model
model = load_model('autonomous_vehicle_model.h5')
# Load the label encoder
label_encoder = joblib.load('label_encoder.joblib')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    # Get user input from the form
    user_input = [float(request.form['distance']),
                  float(request.form['speed']),
                  float(request.form['heading']),
                  float(request.form['lane_position']),
                  float(request.form['acceleration']),
                  float(request.form['turn_rate']),
                  float(request.form['sensor1']),
                  float(request.form['sensor2']),
                  float(request.form['sensor3']),
                  float(request.form['sensor4'])]
    
    # Make prediction for user input
    user_input = np.array([user_input])
    predictions = model.predict(user_input)
    predicted_action = label_encoder.inverse_transform(np.argmax(predictions, axis=1))[0]

    return render_template('index.html', predicted_action=predicted_action)

if __name__ == '__main__':
    app.run(debug=True)
